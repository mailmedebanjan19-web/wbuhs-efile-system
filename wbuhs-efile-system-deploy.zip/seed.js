const fs = require('fs');
const path = require('path');
const db = require('./database');
const bcrypt = require('bcryptjs');

function seed() {
  console.log('--- Seeding WBUHS E-File Database ---');

  const existingUsers = db.getUsers();
  const dbData = db.readDB();

  // Reset or initialize dbData users if empty or re-seed
  dbData.users = [];
  dbData.files = [];
  dbData.notings = [];
  dbData.movements = [];
  dbData.auditLogs = [];

  const initialUsers = [
    {
      id: 'USR-PROG4',
      name: 'Programmer 4',
      email: 'programmer_4@wbuhs.ac.in',
      handle: 'programmer_4',
      username: 'programmer_4',
      password: 'debanjan',
      role: 'SUPER ADMIN',
      department: 'IT & Systems Cell',
      designation: 'Programmer Grade IV',
      phone: '+91 33 2358 9396 Ext 104',
      extension: '104',
      status: 'Active'
    },
    {
      id: 'USR-VC',
      name: 'Prof. (Dr.) Mukul Bhattacharyya',
      email: 'vc@wbuhs.ac.in',
      handle: 'vc',
      username: 'vc',
      password: 'admin',
      role: 'SUPER ADMIN',
      department: 'Vice Chancellor Secretariat',
      designation: 'Hon\'ble Vice Chancellor',
      phone: '+91 33 2358 9396 Ext 101',
      extension: '101',
      status: 'Active'
    },
    {
      id: 'USR-REGISTRAR',
      name: 'Prof. (Dr.) Indranath Kundu',
      email: 'registrar@wbuhs.ac.in',
      handle: 'registrar',
      username: 'registrar',
      password: 'admin',
      role: 'Registrar',
      department: 'Registrar Secretariat',
      designation: 'Registrar',
      phone: '+91 33 2358 9396 Ext 102',
      extension: '102',
      status: 'Active'
    },
    {
      id: 'USR-FO',
      name: 'Shri Lalu Das',
      email: 'fo@wbuhs.ac.in',
      handle: 'fo',
      username: 'fo',
      password: 'user123',
      role: 'Finance Officer',
      department: 'Finance & Accounts Department',
      designation: 'Finance Officer',
      phone: '+91 33 2358 9396 Ext 103',
      extension: '103',
      status: 'Active'
    },
    {
      id: 'USR-COE',
      name: 'Prof. Dr. Anindya Dasgupta',
      email: 'coe@wbuhs.ac.in',
      handle: 'coe',
      username: 'coe',
      password: 'user123',
      role: 'Controller of Exams',
      department: 'Examination Section',
      designation: 'Controller of Examinations',
      phone: '+91 33 2358 9396 Ext 105',
      extension: '105',
      status: 'Active'
    }
  ];

  initialUsers.forEach(u => {
    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(u.password, salt);
    dbData.users.push({
      id: u.id,
      name: u.name,
      email: u.email,
      handle: u.handle,
      username: u.username,
      passwordHash,
      role: u.role,
      department: u.department,
      designation: u.designation,
      phone: u.phone,
      extension: u.extension,
      status: u.status,
      createdAt: new Date().toISOString()
    });
  });

  // Seed sample official sample files
  const sampleFile1 = {
    id: 'FILE-2026-001',
    fileNo: 'WBUHS/REG/2026/001',
    subject: 'Approval of MD/MS Examination Schedule & Center Allocations 2026',
    category: 'Examination & Academics',
    priority: 'Urgent',
    confidentiality: 'Confidential',
    status: 'Pending',
    currentHolderId: 'USR-VC',
    currentHolderName: 'Prof. (Dr.) Mukul Bhattacharyya',
    currentHolderDesignation: 'Hon\'ble Vice Chancellor',
    createdByUserId: 'USR-COE',
    createdByName: 'Prof. Dr. Anindya Dasgupta',
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    attachments: [
      {
        name: 'MD_MS_Exam_Schedule_2026.pdf',
        originalName: 'MD_MS_Exam_Schedule_2026.pdf',
        path: '/uploads/sample_exam_schedule.pdf',
        mimeType: 'application/pdf',
        size: '1.2 MB'
      },
      {
        name: 'Center_Allocation_Budget.xlsx',
        originalName: 'Center_Allocation_Budget.xlsx',
        path: '/uploads/sample_center_budget.xlsx',
        mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        size: '450 KB'
      }
    ]
  };

  const sampleFile2 = {
    id: 'FILE-2026-002',
    fileNo: 'WBUHS/FIN/2026/004',
    subject: 'Procurement of Server Infrastructure & Cyber Security Firewall for e-Office',
    category: 'IT & Capital Procurement',
    priority: 'Immediate',
    confidentiality: 'Standard',
    status: 'Forwarded',
    currentHolderId: 'USR-FO',
    currentHolderName: 'Shri Lalu Das',
    currentHolderDesignation: 'Finance Officer',
    createdByUserId: 'USR-PROG4',
    createdByName: 'Programmer 4',
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    attachments: [
      {
        name: 'IT_Infrastructure_Tender_Draft.docx',
        originalName: 'IT_Infrastructure_Tender_Draft.docx',
        path: '/uploads/sample_tender.docx',
        mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        size: '890 KB'
      }
    ]
  };

  dbData.files.push(sampleFile1, sampleFile2);

  // Seed sample Green Notings for File 1
  dbData.notings.push(
    {
      id: 'NOTE-101',
      fileId: 'FILE-2026-001',
      noteNo: 1,
      authorId: 'USR-COE',
      authorName: 'Prof. Dr. Anindya Dasgupta',
      authorDesignation: 'Controller of Examinations',
      authorDepartment: 'Examination Section',
      content: 'Submitted for kind approval of the Hon\'ble Vice Chancellor regarding the proposed schedule for MD/MS Post Graduate Medical Degree Examinations starting November 2026 across 14 affiliated Medical Colleges. Center allocation matrix and invigilation budget sheet are attached.',
      timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: 'NOTE-102',
      fileId: 'FILE-2026-001',
      noteNo: 2,
      authorId: 'USR-REGISTRAR',
      authorName: 'Prof. (Dr.) Indranath Kundu',
      authorDesignation: 'Registrar',
      authorDepartment: 'Registrar Secretariat',
      content: 'Exam schedule verified as per WBUHS academic calendar 2026. Financial implications checked by Finance Officer. Forwarded to Hon\'ble Vice Chancellor for final administrative sanction.',
      timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
    }
  );

  // Seed sample movements
  dbData.movements.push(
    {
      id: 'MOV-201',
      fileId: 'FILE-2026-001',
      fromUserId: 'USR-COE',
      fromUserName: 'Prof. Dr. Anindya Dasgupta',
      fromUserDesignation: 'Controller of Examinations',
      toUserId: 'USR-REGISTRAR',
      toUserName: 'Prof. (Dr.) Indranath Kundu',
      toUserDesignation: 'Registrar',
      actionTaken: 'For Verification',
      remarks: 'Kindly verify and forward to VC.',
      timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: 'MOV-202',
      fileId: 'FILE-2026-001',
      fromUserId: 'USR-REGISTRAR',
      fromUserName: 'Prof. (Dr.) Indranath Kundu',
      fromUserDesignation: 'Registrar',
      toUserId: 'USR-VC',
      toUserName: 'Prof. (Dr.) Mukul Bhattacharyya',
      toUserDesignation: 'Hon\'ble Vice Chancellor',
      actionTaken: 'For Approval',
      remarks: 'Submitted to Hon\'ble VC for approval.',
      timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: 'MOV-203',
      fileId: 'FILE-2026-002',
      fromUserId: 'USR-PROG4',
      fromUserName: 'Programmer 4',
      fromUserDesignation: 'Programmer Grade IV',
      toUserId: 'USR-FO',
      toUserName: 'Shri Lalu Das',
      toUserDesignation: 'Finance Officer',
      actionTaken: 'For Financial Concurrence',
      remarks: 'Submitted for vetting of tender cost estimate for e-Office server.',
      timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
    }
  );

  db.writeDB(dbData);
  console.log('Seeding complete! 5 Users and 2 Sample Files created successfully.');
}

seed();
