@echo off
title WBUHS E-File Permanent Background Server & Tunnel
cd /d "C:\Users\WBUHS-REG\.gemini\antigravity\scratch\wbuhs-efile-system"

echo Starting WBUHS E-File Express Server...
start /min "WBUHS Node Server" "C:\Program Files\nodejs\node.exe" server.js

timeout /t 3 >nul

echo Starting Cloudflare Public Tunnel...
start /min "Cloudflare Tunnel" "C:\Program Files\nodejs\npx.cmd" cloudflared tunnel --url http://localhost:5000

echo ====================================================
echo WBUHS E-File System Server & Tunnel auto-started!
echo Access Link: http://localhost:5000
echo ====================================================
